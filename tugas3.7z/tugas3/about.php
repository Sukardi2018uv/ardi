<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nascence</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <link href="https://fonts.googleapis.com/css?family=Poppins&display=swap" rel="stylesheet">
</head>
<body>
    <div class="topnav">
        <img src="nascence-logo.png" alt="illust" class="site-logo">
        <ul>
            <li><a href="index.php">Home</a>
            <li><a class="active">About</a>
            <li><a href="contact.php">Contact</a>
        </ul>
    </div>
    
    <div class="about-title">
		<span>About Nascence</span>
	</div>
	<div class="sub-title-about">
		<span>WELCOME TO NASCENCE</span>
    </div>
    
    <img src="1-2.png" alt="illust" class="image-title">

    <div class="desc-about">
		<span>Headquartered in Singapore with operating offices in Indonesia, Nascence focus on providing enterprise business applications for medium to large size of companies. We own one of the most successful HRMS suite of solutions for Indonesia market. We also provided the localized payroll solution for Vietnam market. We have a highly experienced management team and best-in-class professionals who understand your business and technology imperatives. We are always upgrading our technology to provide our customers with the best ROI.<br/><br/>As a technology driven company, we also provide customized solutions to well-qualified customers and projects. We will only take on projects if the customer requirements and expectations are clear as we believe in good quality and on-time delivery. As part of providing overall IT solutions, we also have a team of strong infrastructure professional to provide consulting and implementation of IT infrastructure for our customers.</span>
    </div>
    
    <img src="nascence-logo-about-us.png" alt="illust" class="nascence_logo_about_us">

    <div class="cta">
        <img src="cta-background.png" alt="illust" class="cta-bg2">
        <h3 class="title-cta2">More about us?</h3>
        <p class="desc-cta2">Whether it's in regards to feedback, partnerships, careers, or anything else, we’re here to listen. Don’t be afraid to reach out!</p>
        <a href="contact.php" class="button4">Free Consultation</a>
    </div>

    <div class="blank2">
    
    </div>


</body>
</html>